$(function () {

    $.getJSON('http://dynamic.wpsandpit.co.uk/highmaps/data/jsonp.php?filename=unemployment.csv&callback=?', function (csv) {

        // Parse the CSV Data
        /*Highcharts.data({
            csv: data,
            switchRowsAndColumns: true,
            parsed: function () {
                console.log(this.columns);
            }
        });*/

        // Very simple and case-specific CSV string splitting
        function CSVtoArray(text) {
            return text.replace(/^"/, '')
                .replace(/",$/, '')
                .split('","');
        };

        csv = csv.split(/\n/);

        var countries = {},
            mapChart,
            countryChart,
            numRegex = /^[0-9\.]+$/,
            quoteRegex = /\"/g,
            categories = CSVtoArray(csv[1]).slice(4);

        // Parse the CSV into arrays, one array each country
        $.each(csv.slice(2), function (j, line) {
            var row = CSVtoArray(line),
                data = row.slice(4);

            $.each(data, function (i, val) {
                
                val = val.replace(quoteRegex, '');
                if (numRegex.test(val)) {
                    val = parseInt(val);
                } else if (!val) {
                    val = null;
                }
                data[i] = val;
            });
            countries[row[1]] = {
                name: row[0],
                code3: row[1],
                data: data
            };
        });

        // For each country, use the latest value for current unemployment percentage
        var data = [];
        for (var code3 in countries) {
            var value = null,
                year,
                itemData = countries[code3].data,
                i = itemData.length;

            while (i--) {
                if (typeof itemData[i] === 'number') {
                    value = itemData[i];
                    year = categories[i];
                    break;
                }
            }
            data.push({
                name: countries[code3].name,
                code3: code3,
                value: value,
                year: year
            });
        }
        
        // Add lower case codes to the data set for inclusion in the tooltip.pointFormat
        var mapData = Highcharts.geojson(Highcharts.maps['custom/european-union']);
        $.each(mapData, function () {
            this.id = this.properties['hc-key']; // for Chart.get()
            this.flag = this.id.replace('UK', 'GB').toLowerCase();
        });

        // Wrap point.select to get to the total selected points
        Highcharts.wrap(Highcharts.Point.prototype, 'select', function (proceed) {

            proceed.apply(this, Array.prototype.slice.call(arguments, 1));

            var points = mapChart.getSelectedPoints();

            if (points.length) {
                if (points.length === 1) {
                    $('#info #flag').attr('class', 'flag ' + points[0].flag);
                    $('#info h2').html(points[0].name);
                } else {
                    $('#info #flag').attr('class', 'flag');
                    $('#info h2').html('Comparing countries');

                }
                $('#info .subheader').html('<h4>Historic % unemployment</h4><small><em>Shift + Click on map to compare countries</em></small>')

                if (!countryChart) {
                    countryChart = $('#country-chart').highcharts({
                        chart: {
                            height: 396,
                            width: 380,
                            marginTop: 30,
                            spacingLeft: 15
                        },
                        credits: {
                            enabled: false
                        },
                        title: {
                            text: null
                        },
                        subtitle: {
                            text: null
                        },
                        xAxis: {
                            tickPixelInterval: 60,
                            crosshair: true
                        },
                        yAxis: {
                            title: null,
                            labels: {
                                format: '{value}%'
                                }
                        },
                        tooltip: {
                            shared: true,
                            valueSuffix: '%'

                        },
                        plotOptions: {
                            series: {
                                animation: {
                                    duration: 500
                                },
                                marker: {
                                    enabled: false
                                },
                                threshold: 0,
                                pointStart: parseInt(categories[0]),
                            }
                        }
                    }).highcharts();
                }

                $.each(points, function (i) {
                    // Update
                    if (countryChart.series[i]) {
                        /*$.each(countries[this.code3].data, function (pointI, value) {
                            countryChart.series[i].points[pointI].update(value, false);
                        });*/
                        countryChart.series[i].update({
                            name: this.name,
                            data: countries[this.code3].data,
                            type: points.length > 1 ? 'line' : 'area'
                        }, false);
                    } else {
                        countryChart.addSeries({
                            name: this.name,
                            data: countries[this.code3].data,
                            type: points.length > 1 ? 'line' : 'area'
                        }, false);
                    }
                });
                while (countryChart.series.length > points.length) {
                    countryChart.series[countryChart.series.length - 1].remove(false);
                }
                countryChart.redraw();

            } else {
                $('#info #flag').attr('class', '');
                $('#info h2').html('');
                $('#info .subheader').html('');
                if (countryChart) {
                    countryChart = countryChart.destroy();
                }
            }

        });
        
        // Initiate the map chart
        mapChart = $('#container').highcharts('Map', {
            
            title : {
                text : 'Unemployment in EU Countries<br />(% Total Labour Force)'
            },

            subtitle: {
                text: 'Source: <a href="http://data.worldbank.org/indicator/SL.UEM.TOTL.ZS">The World Bank</a>'
            },

            mapNavigation: {
                enabled: true,
                buttonOptions: {
                    verticalAlign: 'bottom'
                }
            },

            colorAxis: {
                type: 'linear',
                minColor: '#EEEEFF',
                maxColor: '#000022',
                stops: [
                    [0, '#FCFFF5'],
                    [0.25, '#D1DBBD'],
                    [0.5, '#91AA9D'],
                    [0.75, '#3E606F'],
                    [1, '#193441']
                ]

            },

            tooltip: {
                valueSuffix: '%',
                footerFormat: '<span style="font-size: 10px">(Click for details)</span>'
            },

            series : [{
                data : data,
                mapData: mapData,
                joinBy: ['iso-a3', 'code3'],
                name: 'Current unemployment',
                allowPointSelect: true,
                cursor: 'pointer',
                states: {
                    select: {
                        color: '#A4A800',
                        borderColor: '#A4A800',
                        dashStyle: 'solid'
                    }
                }
            }]
        }).highcharts();

        // Pre-select a country
        mapChart.get('gb').select();
    });
});